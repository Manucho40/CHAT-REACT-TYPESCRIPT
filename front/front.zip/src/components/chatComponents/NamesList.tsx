import React, { FC, useEffect, useState } from 'react'
import { Input } from 'antd';
import { UserList } from '../../types/UserList';
import { FaPowerOff } from 'react-icons/fa';
import { relative } from 'path';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '../../app/store';
import { deconnexion, reset } from '../../features/userSlice';



const { Search } = Input;
const onSearch = (value: string) => console.log(value);
export interface ContactsProps{
  contacts: UserList[];
  currentContact: UserList;
  changeChat: (item: UserList) => void;
  userConnect: UserList
}
export const pseudoFirstLetterMaj = (pseudo:string) => {
  let first = '';
  let sup = '';
    for(let i = 0; i < pseudo.length; i++){
    first = pseudo[0].toUpperCase();
      sup = first + pseudo.slice(1)
    }
    return sup

}

const NamesList : FC<ContactsProps> = ({contacts, currentContact, changeChat, userConnect}, ) => {
  const [currIndex, setCurrIndex] = useState<number>(0);

  const dispatch = useDispatch<AppDispatch>();
  const deconnecter = () => {
      dispatch(deconnexion());
      dispatch(reset()) ;
      window.location.reload();
  }

 

  return (
    <div className='namesList' id='nameliste'>
      <div className='searchName'>
      <Search placeholder="input search text" onSearch={onSearch} enterButton />
      </div>
      <ul className='ulname'> 
         {
          contacts.map((item, index) => 
            <li key={index} className={`userList ${index === currIndex  ? "selectTalk" : ""}`}  onClick={() => {setCurrIndex(index); changeChat(item)}}>
            <img src={item.avatar} alt="" />
            <div className='userListInfo'>
              <span className='userListName'>{pseudoFirstLetterMaj(item.pseudo)}</span>
              <span className='userListName'>Online</span>
            </div>
          </li>
            
          )
         }
          
      </ul>
      <div className="userConnecter">
        <div>
          <img src={userConnect.avatar} alt="" />
          <span>{pseudoFirstLetterMaj(userConnect.pseudo)}</span>
        </div>
        <FaPowerOff onClick={deconnecter} size={28} />
      </div>   
    </div>
  )
}

export default NamesList;