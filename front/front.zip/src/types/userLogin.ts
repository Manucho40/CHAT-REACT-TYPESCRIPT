export interface userLogin {
    pseudo: string,
    password: string
}