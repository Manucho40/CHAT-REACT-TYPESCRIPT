export interface UserList {
    _id?: string,
    pseudo: string,
    email: string,
    avatar: string
}
