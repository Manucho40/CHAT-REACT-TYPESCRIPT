export interface User {
    _id?: string,
    pseudo: string,
    email: string,
    password: string,
    token?: string
    avatar: string
}
